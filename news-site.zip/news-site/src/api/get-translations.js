export default async function handler(req, res) {
  const { lang = 'en' } = req.query;

  try {
    const translations = await import(`../translations/${lang}.json`);
    return res.status(200).json(translations.default);
  } catch (error) {
    return res.status(404).json({ error: 'Translation not found' });
  }
}